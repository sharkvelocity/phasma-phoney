// dialogueEngine.js

const narratorBox = document.getElementById('narrator-box');

let currentNarrator = 'Deo';

export function updateNarrator(text, tone = 'neutral') {
  if (!narratorBox) return;
  narratorBox.innerHTML = '';
  const p = document.createElement('p');
  p.className = `narration ${tone}`;
  p.textContent = text;
  narratorBox.appendChild(p);
}

export function appendNarration(text, tone = 'neutral') {
  const p = document.createElement('p');
  p.className = `narration ${tone}`;
  p.textContent = text;
  narratorBox.appendChild(p);
  narratorBox.scrollTop = narratorBox.scrollHeight;
}

export function setNarrator(mode) {
  currentNarrator = mode;
}

export function getNarrator() {
  return currentNarrator;
}

export function clearDialogue() {
  narratorBox.innerHTML = '';
}
