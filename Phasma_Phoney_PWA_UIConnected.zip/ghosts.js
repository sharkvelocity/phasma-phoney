export const ghosts = [
  {
    name: "Spirit",
    traits: ["Calm", "Basic"],
    evidences: ["EMF Level 5", "Spirit Box", "Ghost Writing"]
  },
  {
    name: "Wraith",
    traits: ["No Footsteps", "Teleports"],
    evidences: ["DOTS Projector", "EMF Level 5", "Spirit Box"]
  },
  {
    name: "Phantom",
    traits: ["Photo Vanish", "Sanity Drain"],
    evidences: ["DOTS Projector", "Spirit Box", "Freezing Temperatures"]
  },
  {
    name: "Poltergeist",
    traits: ["Object Thrower", "Loud"],
    evidences: ["Spirit Box", "Ghost Writing", "Fingerprints"]
  },
  {
    name: "Banshee",
    traits: ["Targeted Hunts", "Singing"],
    evidences: ["DOTS Projector", "Ghost Orb", "Fingerprints"]
  },
  {
    name: "Jinn",
    traits: ["Fast With Power", "Electricity Effects"],
    evidences: ["EMF Level 5", "Spirit Box", "Freezing Temperatures"]
  },
  {
    name: "Mare",
    traits: ["Light-Averse", "Power Off"],
    evidences: ["Ghost Orb", "Spirit Box", "Ghost Writing"]
  },
  {
    name: "Revenant",
    traits: ["Slow Unless Seen", "Aggressive"],
    evidences: ["Ghost Writing", "Ghost Orb", "Freezing Temperatures"]
  },
  {
    name: "Demon",
    traits: ["Frequent Hunts", "Cross Reaction"],
    evidences: ["Freezing Temperatures", "Ghost Writing", "Fingerprints"]
  },
  {
    name: "Yurei",
    traits: ["Sanity Drain", "Door Slam"],
    evidences: ["DOTS Projector", "Freezing Temperatures", "Ghost Orb"]
  },
  {
    name: "Oni",
    traits: ["Visible", "Heavy Thrower"],
    evidences: ["EMF Level 5", "Freezing Temperatures", "DOTS Projector"]
  },
  {
    name: "Hantu",
    traits: ["Cold-Speed", "Breath"],
    evidences: ["Ghost Orb", "Freezing Temperatures", "Fingerprints"]
  },
  {
    name: "Yokai",
    traits: ["Voice-Triggered", "Noisy"],
    evidences: ["DOTS Projector", "Spirit Box", "Ghost Orb"]
  },
  {
    name: "Goryo",
    traits: ["DOTS Only on Cam", "Doesn't Roam"],
    evidences: ["EMF Level 5", "DOTS Projector", "Fingerprints"]
  },
  {
    name: "Myling",
    traits: ["Quiet Steps", "Loud Mic"],
    evidences: ["EMF Level 5", "Ghost Writing", "Fingerprints"]
  },
  {
    name: "Onryo",
    traits: ["Candle Hunter", "Fire React"],
    evidences: ["Spirit Box", "Ghost Orb", "Freezing Temperatures"]
  },
  {
    name: "The Twins",
    traits: ["Dual Activity", "Roaming"],
    evidences: ["EMF Level 5", "Spirit Box", "Freezing Temperatures"]
  },
  {
    name: "Raiju",
    traits: ["Electronics Boost", "Speedy"],
    evidences: ["EMF Level 5", "DOTS Projector", "Ghost Orb"]
  },
  {
    name: "Obake",
    traits: ["Fingerprint Shifter", "Rare Prints"],
    evidences: ["EMF Level 5", "Ghost Orb", "Fingerprints"]
  },
  {
    name: "The Mimic",
    traits: ["Copies Others", "Extra Evidence"],
    evidences: ["Spirit Box", "Fingerprints", "Freezing Temperatures", "Ghost Orb"]
  },
  {
    name: "Moroi",
    traits: ["Curses Sanity", "Fast If Cursed"],
    evidences: ["Spirit Box", "Ghost Writing", "Freezing Temperatures"]
  },
  {
    name: "Deogen",
    traits: ["Always Finds You", "Breathing"],
    evidences: ["Spirit Box", "Ghost Writing", "DOTS Projector"]
  },
  {
    name: "Thaye",
    traits: ["Ages Over Time", "Fast to Slow"],
    evidences: ["Ghost Writing", "DOTS Projector", "Ghost Orb"]
  },
  {
    name: "Succubus",
    traits: ["Seductive", "Narrates", "Emotionally Reactive"],
    evidences: ["Spirit Box", "DOTS Projector", "Ghost Orb"]
  }
];

export function randomizeGhost() {
  return ghosts[Math.floor(Math.random() * ghosts.length)];
}

export function getGhostByName(name) {
  return ghosts.find(g => g.name.toLowerCase() === name.toLowerCase());
}
