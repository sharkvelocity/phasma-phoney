// mechanics.js

import { currentGhost } from './ghostData.js';
import { updateStats } from './statistics.js';
import { updateJournal } from './journal.js';

let playerSanity = 100;
let turnCount = 0;
let smudgeCooldown = 0;
let huntActive = false;

export function initializeMechanics() {
  playerSanity = 100;
  turnCount = 0;
  smudgeCooldown = 0;
  huntActive = false;
}

export function nextTurn(actions = 1) {
  for (let i = 0; i < actions; i++) {
    turnCount++;
    reduceSanity();
    if (smudgeCooldown > 0) smudgeCooldown--;
    checkGhostActivity();
    updateStats(turnCount, playerSanity);
  }
}

function reduceSanity() {
  let sanityLoss = Math.floor(Math.random() * 4) + 2;
  playerSanity = Math.max(0, playerSanity - sanityLoss);
}

function checkGhostActivity() {
  if (Math.random() < currentGhost.activityRate) {
    triggerEvent();
  }
}

function triggerEvent() {
  const eventType = Math.random();
  if (eventType < 0.3) {
    logNarration(`${currentGhost.name} flickers the lights.`);
  } else if (eventType < 0.6) {
    logNarration(`${currentGhost.name} whispers something chilling...`);
  } else {
    logNarration(`${currentGhost.name} slams a door shut nearby.`);
  }

  if (playerSanity < 30 && !huntActive && Math.random() < 0.4) {
    startHunt();
  }
}

export function startHunt() {
  huntActive = true;
  logNarration(`${currentGhost.name} has started a hunt!`);
}

export function useSmudgeStick() {
  if (smudgeCooldown === 0) {
    logNarration(`You use a smudge stick. The air shimmers briefly.`);
    smudgeCooldown = 5;
    if (huntActive) {
      logNarration(`The hunt is repelled... for now.`);
      huntActive = false;
    }
  } else {
    logNarration(`You can't use another smudge stick just yet.`);
  }
}

export function useCandle(tier = 1) {
  let burnTime;
  if (tier === 1) burnTime = 10;
  else if (tier === 2) burnTime = 20;
  else burnTime = Infinity;

  logNarration(`You light a Tier ${tier} candle. It will last ${burnTime === Infinity ? 'forever' : burnTime + ' turns'}.`);
}

function logNarration(text) {
  const narratorBox = document.getElementById('narrator-box');
  if (narratorBox) {
    narratorBox.innerHTML += `<p>${text}</p>`;
  }
  updateJournal(text);
}

export function getSanity() {
  return playerSanity;
}

export function getTurnCount() {
  return turnCount;
}
