// narrator.js
import { getCurrentSanity, getCurrentGhost, getGhostBehavior } from './game.js';
import { journalLog } from './journal.js';

let activeNarrator = 'deo'; // can be 'deo' or 'succubus'

export function setNarrator(name) {
  activeNarrator = name;
}

export function getNarrator() {
  return activeNarrator;
}

const narratorLines = {
  deo: {
    greeting: [
      "Welcome back, investigator. Let’s hope this one doesn’t kill you.",
      "Another haunting? Another chance to prove yourself.",
      "Let’s begin. Ghosts don’t wait."
    ],
    evidence: [
      "That’s a solid clue. Mark it down.",
      "EMF is active... something's stirring.",
      "I’d write that one in the journal if I were you."
    ],
    hunt: [
      "Get ready. It's coming.",
      "RUN. Now!",
      "Smudge. Hide. Pray."
    ],
    victory: [
      "Well done. You’ve survived again.",
      "Nice deduction. You got the ghost right.",
      "You’re not dead. That’s a win."
    ],
    death: [
      "Tough break, investigator. You’ll do better next time.",
      "Dead again? At this rate, you’ll become the ghost.",
      "You tried. But you failed."
    ]
  },
  succubus: {
    greeting: [
      "Back for more? I’ve missed you in the dark...",
      "Let’s see if you’re as brave as you pretend to be.",
      "I’ll whisper truths... if you survive."
    ],
    evidence: [
      "Mmm… something responded. Delicious.",
      "That was... revealing. Write it down.",
      "Do you feel that? It’s watching you now."
    ],
    hunt: [
      "Hide, sweet thing... before it tears into you.",
      "You smell like fear. Run.",
      "Shhh. Let it pass... if it can resist you."
    ],
    victory: [
      "So clever. You solved me again.",
      "You live... for now. Come back soon.",
      "Another success... I’m beginning to like you."
    ],
    death: [
      "Oh, you screamed so sweetly.",
      "Dead already? I expected more...",
      "Your soul slipped so easily into the dark."
    ]
  }
};

export function narratorSpeak(eventType) {
  const lines = narratorLines[activeNarrator][eventType];
  if (!lines) return;
  const line = lines[Math.floor(Math.random() * lines.length)];
  const narratorBox = document.getElementById('narrator-box');
  narratorBox.innerText = `${capitalize(activeNarrator)}: ${line}`;
  journalLog(`${capitalize(activeNarrator)} says: ${line}`);
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}
