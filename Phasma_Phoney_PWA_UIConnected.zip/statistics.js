const statsKey = 'phoneyUserStats';

let stats = {
  gamesPlayed: 0,
  correctGuesses: 0,
  deaths: 0,
  ghostsIdentified: {},
};

export function loadStats() {
  const saved = localStorage.getItem(statsKey);
  if (saved) {
    stats = JSON.parse(saved);
  }
}

export function saveStats() {
  localStorage.setItem(statsKey, JSON.stringify(stats));
}

export function recordGame(outcome, ghostName) {
  stats.gamesPlayed++;
  if (outcome === 'correct') stats.correctGuesses++;
  if (outcome === 'death') stats.deaths++;
  if (!stats.ghostsIdentified[ghostName]) {
    stats.ghostsIdentified[ghostName] = 0;
  }
  stats.ghostsIdentified[ghostName]++;
  saveStats();
}

export function getStatsSummary() {
  const lines = [
    `Games Played: ${stats.gamesPlayed}`,
    `Correct Guesses: ${stats.correctGuesses}`,
    `Deaths: ${stats.deaths}`,
    '',
    'Ghosts Identified:',
  ];
  for (const [name, count] of Object.entries(stats.ghostsIdentified)) {
    lines.push(`• ${name}: ${count}`);
  }
  return lines.join('\n');
}
